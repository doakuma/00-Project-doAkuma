//문자열 길이 검사(한글2byte처리)
function strLenVrify(str, len) {
	var strLen = str.length;
	var strByteLen = 0;
	for (var i = 0; i < strLen; i++) {
		if(escape(str.charAt(i)).length >= 4){
			strByteLen += 2;
		}else if(escape(str.charAt(i)) == "%A7"){
			console.log(str.charAt(i));
			strByteLen += 2;
		}else{
			if(escape(str.charAt(i)) != "%0D"){
				strByteLen++;
			}
		}
	}
	if(strByteLen<=len){
		return true;
	}else{
		return false;
	}
}

//숫자(int, double) 길이 검사
function numLenVrify(num, len1, len2){
	if(num.indexOf(".")>0){
		var nums = num.split('.');
		if(nums.length!=2){
			return false;
		}else{
			if(nums[0].length<=len1){
				if(nums[1].length<=len2 || nums[1] == 0){
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
		}
	}else{
		if(num.length<=len1){
			return true;
		}else{
			return true;
		}
	}
}

//항목(입력창) 초기화
//ids:id 배열
function inputTextReset(ids){
	for (var i = 0; i < ids.length; i++) {
		$("#"+ids[i]+"").val("");
	}
}

//파일사이즈 측정
function fn_showFileSize(idName){
	console.log(idName);
	if(!window.FileReader)
	{
		return -99;
	}
	else
	{
		input = document.getElementById(idName);
		file = input.files[0];
		return file.size;
	}
}

//숫자+"."만 입력하도록 제한
function inputLimit(){
	$(".onlyNumber").keydown(function (e) {
		if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 || (e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true ) ) || (e.keyCode >= 35 && e.keyCode <= 40)) {
            return;
   		}	
		if(e.shiftKey || e.keyCode < 48 || e.keyCode > 57  && e.keyCode < 96 || e.keyCode > 105){
			e.preventDefault();
		};
	});
}

function callFileDown(path){
	$.ajax({
		url: "/fileCheck.do",
		type: "POST",
		data: {
			path:path,
		},
		dataType: "json",
		success: function(data) {
			if(!data.isFile){
				alert("파일을 찾을 수 없습니다.\n관리자에게 문의하세요.");
				return;
			}else{
				if(confirm("해당파일을 다운로드 하시겠습니까?")){
				   	DownLoader.setting();
				   	$("#excelForm").attr("target", "downFrames");
				   	$("#excelForm").attr("action", "/fileDownload.do");
				   	$("#excelForm").attr("method","post");
				   	
				   	var name = "";
				   	name = path.substring(path.lastIndexOf("/")+1);
				   	
			   		var filePath = '<input type="hidden" id="path" name="path" value="'+path+'">';
				   	var fileName = '<input type="hidden" id="name" name="name" value="'+name+'">';
				   	
					$("#excelForm").append(filePath).append(fileName);
				   	$("#excelForm").submit();
				   	
				   	$('form#excelForm > input[name=path]').remove();
				  	$('form#excelForm > input[name=name]').remove();
				}else{
					return;
				}
			}
		}
	});
}
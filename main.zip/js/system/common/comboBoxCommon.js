var gDetail_type="P_TYPE";

function setComboBox(){
	
	//상위기관 콤보박스 선택시
	$('select#selectUpperInstt').change(function() {
		onSelectUpperInsttChange($(this));
	});
	
	onSelectUpperInsttChange = function(srcElement) {
		resetSelect($('select#selectInstt'));
		var selectParam = $('#selectUpperInstt option:selected').val();
		
		$.ajax({
			url : '/childDeptList.do',
			type: 'POST',
			dataType: 'json',
			data: {
				upperDeptCode : selectParam
			},
			success: function(data) {
				for(var i=0; i < data.length; i++){
					$("#selectInstt").append("<option value='"+data[i].deptCode+"'>"+data[i].deptNm+"</option>");
				}
			},//end success
			error: function(xhr, textStatus, error) {
  				alert("에러메세지 : "+error);
  			}
		});	//end Ajax
	}; //end 
	
	//상위선택시 하위초기화
	resetSelect = function(destElement) {
		destElement.empty();
		destElement.append("<option value=''>선택</option>");
	};
	
}

function changeCheck(){
	$('select#selDetailCtprvn').change(function() {
		evtChgDetailCtprvn('selDetailSig', $('#selDetailCtprvn option:selected').val());
	});
	$('select#selDetailSig').change(function() {
		evtChgDetailSig();
	});
	$('select#selParcelEmd').change(function() {
		evtChgParcelEmd();
	});
	$('select#selRoadIndex').change(function() {
		evtChgDetailSig();
	});
}

/*시도목록*/
function getCtprvnList(selNm) {
	$.ajax({
		type : 'post',
		async : true,
		url : '/map/ctprvnList.do',
		//url:'/map/ctprvnList.do',
		data : {},
		beforeSend : function(xmlHttpRequest) {
 			xmlHttpRequest.setRequestHeader("AJAX", "true"); 
		},
		success : function(data) {
			setCtprnInfo(selNm, data);
		},
		error : function(xhr, status, error) {
			if(xhr.status == "901"){
				alert("로그인 후 이용해 주십시오.");
				location.href="/main.do";
				return;
			}
			alert('error');
		},
		complete : function() {
		}
	});
}

/* 시군구 목록 */
function getSigList(selNm, ctprvn_cd) {
	$.ajax({
		type : 'post',
		async : true,
		url : '/map/sigList.do',
		data : {
			'ctprvn_cd' : ctprvn_cd
		},
		beforeSend : function(xmlHttpRequest) {
 			xmlHttpRequest.setRequestHeader("AJAX", "true"); 
		},
		success : function(data) {
			setSigInfo(selNm, data);					
		},
		error : function(xhr, status, error) {
			if(xhr.status == "901"){
				alert("로그인 후 이용해 주십시오.");
				location.href="/main.do";
				return;
			}
			alert('error');
		},
		complete : function() {
		}
	});
}

/* 읍면동 목록 */
function getEmdList(selNm, sig_cd) {
	$.ajax({
		type : 'post',
		async : true,
		url : '/map/emdList.do',
		data : {
			'sig_cd' : sig_cd
		},
		beforeSend : function(xmlHttpRequest) {
 			xmlHttpRequest.setRequestHeader("AJAX", "true"); 
		},
		success : function(data) {
			/*//상세검색 >> 도로명이 선택되었을 경우
			if($('#addressCondition').children()[0].className == "current") {					
				getRoadNmList('selRoadNam', $('#selRoadIndex option:selected').val(), $('#selDetailSig option:selected').val());
			}	
			// 그 외의 경우
			else	*/setEmdInfo(selNm, data);
		},
		error : function(xhr, status, error) {
			if(xhr.status == "901"){
				alert("로그인 후 이용해 주십시오.");
				location.href="/main.do";
				return;
			}
			alert('error');
		},
		complete : function() {
		}
	});
}

/* 리 목록 */
function getLiList(selNm, emd_cd) {
	$.ajax({
		type : 'post',
		async : true,
		url : '/map/liList.do',
		data : {
			'emd_cd' : emd_cd
		},
		beforeSend : function(xmlHttpRequest) {
 			xmlHttpRequest.setRequestHeader("AJAX", "true"); 
		},
		success : function(data) {
			setLiInfo(selNm, data);
		},
		error : function(xhr, status, error) {
			if(xhr.status == "901"){
				alert("로그인 후 이용해 주십시오.");
				location.href="/main.do";
				return;
			}
			alert('error');
		},
		complete : function() {
		}
	});
}

/* 도로명 목록 */
function getRoadNmList(selNm, index_key, sig_cd) {
	$.ajax({
		type : 'post',
		async : true,
		url : '/map/roadNamList.do',
		data : {
			'index_key' : index_key,
			'sig_cd' : sig_cd
		},
		beforeSend : function(xmlHttpRequest) {
 			xmlHttpRequest.setRequestHeader("AJAX", "true"); 
		},
		success : function(data) {
			setRoadNamInfo(selNm, data);
		},
		error : function(xhr, status, error) {
			if(xhr.status == "901"){
				alert("로그인 후 이용해 주십시오.");
				location.href="/main.do";
				return;
			}
			alert('error');
		},
		complete : function() {
		}
	});
}

/*시도 목록 초기화*/
function setCtprnInfo(selNm, data){
	$("#"+selNm).empty();
	$("#"+selNm).append("<option value='choice'>::선택::</option>");
	
	for(var i=0; i < data.list.length; i++){
		$("#" + selNm).append("<option value='"+data.list[i].ctprvn_cd+"'>"+data.list[i].ctp_kor_nm+"</option>");
	}
	$("#" + selNm).append("<option value='36'>세종특별자치시</option>");
}

/*시군구 목록 초기화*/
function setSigInfo(selNm, data){
	$("#"+selNm).empty();
	$("#"+selNm).append("<option value='choice'>::선택::</option>");
	
	for(var i=0; i < data.list.length; i++){
		$("#"+selNm).append("<option value='"+data.list[i].sig_cd+"'>"+data.list[i].sig_kor_nm+"</option>");
	}
}

/*읍면동 목록 초기화*/
function setEmdInfo(selNm, data){
	$("#"+selNm).empty();
	$("#"+selNm).append("<option value='choice'>::선택::</option>");
	
	for(var i=0; i < data.list.length; i++){
		$("#"+selNm).append("<option value='"+data.list[i].emd_cd+"'>"+data.list[i].emd_kor_nm+"</option>");
	}
	//evtChgDetailSig();
}

/*리 목록 초기화*/
function setLiInfo(selNm, data){
	$("#"+selNm).empty();
	$("#"+selNm).append("<option value='choice'>::선택::</option>");
	
	for(var i=0; i < data.list.length; i++){
		$("#"+selNm).append("<option value='"+data.list[i].li_cd+"'>"+data.list[i].li_kor_nm+"</option>");
	}
}

/*도로명 목록 초기화*/
function setRoadNamInfo(selNm, data){
	$("#"+selNm).empty();
	$("#"+selNm).append("<option value='choice'>::선택::</option>");
	
	for(var i=0; i < data.list.length; i++){
		$("#"+selNm).append("<option value='"+data.list[i].rn_cd+"'>"+data.list[i].rn+"</option>");
	}
}

/*기초구역검색 시도목록 선택 이벤트 핸들러*/
function evtChgBasCtprvn(selNm, ctprvn_cd){
	getSigList(selNm, ctprvn_cd);
}

/*상세 검색 시도목록 선택 이벤트 함수*/
function evtChgDetailCtprvn(selNm, ctprvn_cd){
	getSigList(selNm, ctprvn_cd);
	
	$("#selRoadNam").empty();
	$("#selRoadNam").append("<option value='choice'>::선택::</option>");
	$("#selParcelEmd").empty();
	$("#selParcelEmd").append("<option value='choice'>::선택::</option>");
	$("#selParcelLi").empty();
	$("#selParcelLi").append("<option value='choice'>::선택::</option>");
	$("#selBuldEmd").empty();
	$("#selBuldEmd").append("<option value='choice'>::선택::</option>");
	$("#selAdminEmd").empty();
	$("#selAdminEmd").append("<option value='choice'>::선택::</option>");
	$("#selAdminLi").empty();
	$("#selAdminLi").append("<option value='choice'>::선택::</option>");
	
	/*if(gDetail_type == "A_TYPE"){
		
		var whereText = null;
		//36 == 세종시
		if($('#selDetailCtprvn option:selected').val() == '36'){
			whereText = "SIG_CD=!!"+$('#selDetailCtprvn option:selected').val()+"110!!";
			//alert(whereText);
			mapMove(baseMapUrl, gSigLayerIndex, whereText);//시경계 이동
		}else{			
			whereText = "CTPRVN_CD=!!"+$('#selDetailCtprvn option:selected').val()+"!!";
			//alert(whereText);
			mapMove(baseMapUrl, gCtprvnLayerIndex, whereText);//시경계 이동
		}
	}*/
}

/*상세 검색 시군구 목록 선택 이벤트 함수*/
function evtChgDetailSig(){
	if($('#selDetailSig option:selected').val() != 'choice'){
		getEmdList('selParcelEmd', $('#selDetailSig option:selected').val());
		getRoadNmList('selRoadNam', $('#selRoadIndex option:selected').val(), $('#selDetailSig option:selected').val());
	}
	$("#selParcelLi").empty();
	$("#selParcelLi").append("<option value='choice'>::선택::</option>");
}
function evtChgParcelEmd(){
	if($('#selParcelEmd option:selected').val() != 'choice'){
		getLiList('selParcelLi', $('#selParcelEmd option:selected').val());
	}
}

/*function evtChgAdminEmd(){
	if($('#selAdminEmd option:selected').val() != 'choice'){
		getLiList('selAdminLi', $('#selAdminEmd option:selected').val());
		
		var whereText = "EMD_CD=!!"+$('#selAdminEmd option:selected').val()+"!!";
		mapMove(baseMapUrl, gEmdLayerIndex, whereText);//시군구 경계
	}
}

function evtChgAdminLi(){
	var whereText = "LI_CD=!!"+$('#selAdminLi option:selected').val()+"!!";
	mapMove(baseMapUrl, gLiLayerIndex, whereText);//시군구 경계
	
}*/
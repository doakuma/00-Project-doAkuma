$(function(){
	//tab style content action
	$('.area-tabContent').each(function(){
		$(this).find('>div').eq(0).show().siblings().hide();
	});
	$('.area-tabList button').on('click',function(){
		tabListInx=$(this).parent().index();
		$(this).parent().addClass('current').siblings().removeClass('current');
		$(this).closest('.area-tabList').next('.area-tabContent').find('>div').eq(tabListInx).show().siblings().hide();
	});

	// pagination 선택 컬러
	$('.pagination ul button').on('click',function(){
		$(this).parent().addClass('current').siblings().removeClass('current');
	});

	// 팝업창 닫기
	$('.btn-closepop').on('click',function(){
		$(this).parent().hide();
	});
	
	//check box 전체 선택
	$('.checkAll').on('click',function(){ 
		if($(this).is(':checked')){
			$(this).closest('thead').next('tbody').find('input[type="checkbox"]').prop({checked:true});
		}
		else{
			$(this).closest('thead').next('tbody').find('input[type="checkbox"]').prop({checked:false});
		}
	});

	// content 높이
	$(window).on('load resize',function(){
		winHeight=$(window).height();
		$('.container').css({minHeight:winHeight-25});

		cotainerHeight=$('.container').height();
		$('.content').outerHeight(cotainerHeight);

		contentHeight=$('.container').outerHeight();
		$('.aside').outerHeight(contentHeight);
	});

	// lnb 메뉴 보이기 액션
	$('.lnb ul ul').hide();
	$('.lnb li.current').find('>ul').show();
	$('.lnb>ul>li').on('mouseenter',function(){
		$(this).find('>ul').slideDown();
	});
	$('.lnb>ul>li>ul>li').on('mouseenter',function(){
		$(this).find('>ul').slideDown();
	});
//	$('.lnb>ul>li>ul>li>ul>li').on('mouseenter',function(){
//		$(this).find('>ul').stop().slideDown();
//	});
	
	
	$('.lnb>ul>li').on('mouseleave',function(){
		if($(this).hasClass('current')){
			$(this).find('>ul').show();
		}
		else{$(this).find('ul').slideUp();}
	});
	$('.lnb>ul>li>ul>li').on('mouseleave',function(){
		if($(this).hasClass('current')){
			$(this).find('>ul').show();
		}
		else{$(this).find('ul').slideUp();}
	});
//	$('.lnb>ul>li>ul>li>ul>li').on('mouseleave',function(){
//		if($(this).hasClass('current')){
//			$(this).find('>ul').show();
//		}
//		else{$(this).find('ul').stop().slideUp();}
//	});
	
	// dl 컨텐츠 슬라이드
	$('dl.slideContent dt button').on('click',function(){
		$(this).parent().toggleClass('closed');
		$(this).parent().next('dd').slideToggle();
	});
	
	// 로그인페이지 - 아이디, 패스워드 텍스트
	$('.area-insertId .wrap-input input').on('focus',function(){
		$(this).prev('label').hide();
	});
	$('.area-insertId .wrap-input input').on('focusout',function(){
		if($(this).val()==''){
			$(this).prev('label').show();
		}
		else{$(this).prev('label').hide();}
	});

});